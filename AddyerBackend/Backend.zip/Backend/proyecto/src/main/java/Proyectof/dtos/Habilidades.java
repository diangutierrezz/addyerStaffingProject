package Proyectof.dtos;

public class Habilidades {

    private int id;
    private String habilidad;

  public Habilidades(int id, String habilidad) {
    this.id = id;
    this.habilidad = habilidad;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getHabilidad() {
    return habilidad;
  }

  public void setHabilidad(String habilidad) {
    this.habilidad = habilidad;
  }

  @Override
  public String toString() {
    return "Habilidades{" +
      "id=" + id +
      ", habilidad='" + habilidad + '\'' +
      '}';
  }
}
